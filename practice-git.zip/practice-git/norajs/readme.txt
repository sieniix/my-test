Thanks yo for the practice project :) Gonna mess around here a little.

Nora
Hello
