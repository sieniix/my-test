#Lets start markdown

I just now heard about markdown

Also have an understanding of git but github has me confused
